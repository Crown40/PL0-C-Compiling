# PL0-C-Compiling  
GDUT Course Design
PL0.__ is the Main File  
Ep__.PL0 is test file  
fa__.tmp is generated from PL0.exe  
